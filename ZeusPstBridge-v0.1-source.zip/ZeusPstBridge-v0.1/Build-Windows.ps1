param(
    [ValidateSet("win-x64", "win-arm64")]
    [string]$Runtime = "win-x64"
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$project = Join-Path $root "ZeusPstBridge\ZeusPstBridge.csproj"
$output = Join-Path $root "publish\$Runtime"

Write-Host "ZeusPstBridge Windows publish" -ForegroundColor Cyan

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Host "The .NET 8 SDK is not installed." -ForegroundColor Yellow
    Write-Host "Install it from: https://dotnet.microsoft.com/download/dotnet/8.0"
    Write-Host "Choose the Windows SDK, then run this script again."
    exit 1
}

$version = (& dotnet --version).Trim()
Write-Host "Using .NET SDK $version"

if (Test-Path $output) {
    Remove-Item $output -Recurse -Force
}

& dotnet publish $project `
    --configuration Release `
    --runtime $Runtime `
    --self-contained true `
    --output $output `
    /p:PublishSingleFile=true `
    /p:IncludeNativeLibrariesForSelfExtract=true `
    /p:DebugType=None `
    /p:DebugSymbols=false

if ($LASTEXITCODE -ne 0) {
    throw "dotnet publish failed with exit code $LASTEXITCODE"
}

Write-Host ""
Write-Host "Published successfully:" -ForegroundColor Green
Write-Host (Join-Path $output "ZeusPstBridge.exe")
