using System.Globalization;
using System.Text;
using ZeusPstBridge.Models;
using ZeusPstBridge.Services;

namespace ZeusPstBridge.Protocol;

public sealed class HamlibProtocol
{
    private const int RigOk = 0;
    private const int RigInvalidParameter = -1;
    private const int RigNotImplemented = -4;
    private const int RigTimeout = -5;

    private readonly RotatorConfig _config;
    private readonly Func<double?> _getCurrentAzimuth;
    private readonly Func<double?> _getTargetAzimuth;
    private readonly Func<double, Task> _setAzimuth;
    private readonly Func<Task> _stop;
    private readonly Func<Task> _park;
    private readonly LogService _logger;

    public HamlibProtocol(
        RotatorConfig config,
        Func<double?> getCurrentAzimuth,
        Func<double?> getTargetAzimuth,
        Func<double, Task> setAzimuth,
        Func<Task> stop,
        Func<Task> park,
        LogService logger)
    {
        _config = config;
        _getCurrentAzimuth = getCurrentAzimuth;
        _getTargetAzimuth = getTargetAzimuth;
        _setAzimuth = setAzimuth;
        _stop = stop;
        _park = park;
        _logger = logger;
    }

    public async Task<HamlibCommandResult> ExecuteAsync(string input)
    {
        var command = ParsedCommand.Parse(input);

        if (command.IsCommentOrEmpty)
        {
            return new HamlibCommandResult(string.Empty, false);
        }

        if (command.IsQuit)
        {
            return new HamlibCommandResult(string.Empty, true);
        }

        try
        {
            switch (command.CanonicalName)
            {
                case "set_pos":
                    return await SetPositionAsync(command).ConfigureAwait(false);

                case "get_pos":
                    return GetPosition(command);

                case "stop":
                    await _stop().ConfigureAwait(false);
                    return Success(command, "stop", command.ArgumentText);

                case "park":
                    await _park().ConfigureAwait(false);
                    return Success(command, "park", command.ArgumentText);

                case "get_info":
                    return GetValues(
                        command,
                        "get_info",
                        [("Info", "ZeusPstBridge PstRotatorAz UDP azimuth bridge")]);

                case "dump_state":
                    return DumpState(command);

                case "dump_caps":
                    return DumpCapabilities(command);

                case "move":
                case "reset":
                case "set_conf":
                case "send_cmd":
                    return Error(command, command.CanonicalName, RigNotImplemented);

                case "help":
                    return Help(command);

                default:
                    _logger.Warn($"[{_config.Name}] Unsupported Hamlib command: {input}");
                    return Error(command, command.CanonicalNameOrOriginal, RigInvalidParameter);
            }
        }
        catch (ArgumentException ex)
        {
            _logger.Warn($"[{_config.Name}] Invalid Hamlib command '{input}': {ex.Message}");
            return Error(command, command.CanonicalNameOrOriginal, RigInvalidParameter);
        }
        catch (Exception ex)
        {
            _logger.Error($"[{_config.Name}] Hamlib command failed: {ex.Message}");
            return Error(command, command.CanonicalNameOrOriginal, -6);
        }
    }

    private async Task<HamlibCommandResult> SetPositionAsync(ParsedCommand command)
    {
        if (command.Arguments.Length < 1 ||
            !double.TryParse(command.Arguments[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var azimuth))
        {
            return Error(command, "set_pos", RigInvalidParameter);
        }

        if (command.Arguments.Length > 1 &&
            !double.TryParse(command.Arguments[1], NumberStyles.Float, CultureInfo.InvariantCulture, out _))
        {
            return Error(command, "set_pos", RigInvalidParameter);
        }

        if (azimuth < _config.MinAzimuth || azimuth > _config.MaxAzimuth)
        {
            _logger.Warn(
                $"[{_config.Name}] Rejected azimuth {azimuth:0.###}; configured range is " +
                $"{_config.MinAzimuth:0.###} to {_config.MaxAzimuth:0.###}");
            return Error(command, "set_pos", RigInvalidParameter);
        }

        await _setAzimuth(azimuth).ConfigureAwait(false);
        return Success(command, "set_pos", command.ArgumentText);
    }

    private HamlibCommandResult GetPosition(ParsedCommand command)
    {
        var azimuth = _getCurrentAzimuth();
        if (!azimuth.HasValue)
        {
            return Error(command, "get_pos", RigTimeout);
        }

        return GetValues(
            command,
            "get_pos",
            [
                ("Azimuth", azimuth.Value.ToString("0.000000", CultureInfo.InvariantCulture)),
                ("Elevation", "0.000000")
            ]);
    }

    private HamlibCommandResult DumpState(ParsedCommand command)
    {
        var lines = new[]
        {
            "1",
            "2",
            $"min_az={_config.MinAzimuth.ToString("0.000000", CultureInfo.InvariantCulture)}",
            $"max_az={_config.MaxAzimuth.ToString("0.000000", CultureInfo.InvariantCulture)}",
            "min_el=0.000000",
            "max_el=0.000000",
            "south_zero=0",
            "rot_type=Azimuth",
            "done"
        };

        return RawValues(command, "dump_state", lines);
    }

    private HamlibCommandResult DumpCapabilities(ParsedCommand command)
    {
        var lines = new[]
        {
            "Caps dump for model: ZeusPstBridge PstRotatorAz UDP",
            "Mfg Name: PstRotatorAz",
            "Model Name: UDP Bridge",
            "Can set Position: Y",
            "Can get Position: Y",
            "Can Stop: Y",
            "Can Park: Y",
            "Can Move: N",
            $"Min Azimuth: {_config.MinAzimuth.ToString("0.000000", CultureInfo.InvariantCulture)}",
            $"Max Azimuth: {_config.MaxAzimuth.ToString("0.000000", CultureInfo.InvariantCulture)}",
            "Min Elevation: 0.000000",
            "Max Elevation: 0.000000",
            "done"
        };

        return RawValues(command, "dump_caps", lines);
    }

    private static HamlibCommandResult Help(ParsedCommand command)
    {
        var lines = new[]
        {
            "P, set_pos: set azimuth/elevation",
            "p, get_pos: read azimuth/elevation",
            "S, stop: stop rotator",
            "K, park: park rotator",
            "_, get_info: bridge information",
            "dump_state: rotator limits",
            "1, dump_caps: capabilities",
            "q: close connection"
        };

        return RawValues(command, "help", lines);
    }

    private static HamlibCommandResult Success(ParsedCommand command, string longName, string argumentText)
    {
        if (!command.IsExtended)
        {
            return new HamlibCommandResult("RPRT 0\n", false);
        }

        return new HamlibCommandResult(
            FormatExtended(command, longName, argumentText, [], RigOk),
            false);
    }

    private static HamlibCommandResult Error(ParsedCommand command, string longName, int errorCode)
    {
        if (!command.IsExtended)
        {
            return new HamlibCommandResult($"RPRT {errorCode}\n", false);
        }

        return new HamlibCommandResult(
            FormatExtended(command, longName, command.ArgumentText, [], errorCode),
            false);
    }

    private static HamlibCommandResult GetValues(
        ParsedCommand command,
        string longName,
        IReadOnlyList<(string Key, string Value)> values)
    {
        if (!command.IsExtended)
        {
            var builder = new StringBuilder();
            foreach (var (_, value) in values)
            {
                builder.Append(value).Append('\n');
            }

            return new HamlibCommandResult(builder.ToString(), false);
        }

        return new HamlibCommandResult(
            FormatExtended(command, longName, command.ArgumentText, values, RigOk),
            false);
    }

    private static HamlibCommandResult RawValues(
        ParsedCommand command,
        string longName,
        IReadOnlyList<string> lines)
    {
        if (!command.IsExtended)
        {
            return new HamlibCommandResult(string.Join("\n", lines) + "\n", false);
        }

        var separator = command.ResponseSeparator;
        var builder = new StringBuilder();
        builder.Append(longName).Append(':');
        if (!string.IsNullOrWhiteSpace(command.ArgumentText))
        {
            builder.Append(' ').Append(command.ArgumentText);
        }
        builder.Append(separator);

        foreach (var line in lines)
        {
            builder.Append(line).Append(separator);
        }

        builder.Append("RPRT 0").Append(separator);
        return new HamlibCommandResult(builder.ToString(), false);
    }

    private static string FormatExtended(
        ParsedCommand command,
        string longName,
        string argumentText,
        IReadOnlyList<(string Key, string Value)> values,
        int resultCode)
    {
        var separator = command.ResponseSeparator;
        var builder = new StringBuilder();
        builder.Append(longName).Append(':');
        if (!string.IsNullOrWhiteSpace(argumentText))
        {
            builder.Append(' ').Append(argumentText);
        }
        builder.Append(separator);

        foreach (var (key, value) in values)
        {
            builder.Append(key).Append(": ").Append(value).Append(separator);
        }

        builder.Append("RPRT ").Append(resultCode).Append(separator);
        return builder.ToString();
    }

    private sealed record ParsedCommand(
        string Original,
        string CanonicalName,
        string[] Arguments,
        string ArgumentText,
        bool IsExtended,
        char ResponseSeparator,
        bool IsQuit,
        bool IsCommentOrEmpty)
    {
        public string CanonicalNameOrOriginal =>
            string.IsNullOrWhiteSpace(CanonicalName) ? Original : CanonicalName;

        public static ParsedCommand Parse(string input)
        {
            var original = input ?? string.Empty;
            var text = original.Trim();
            if (text.Length == 0 || text.StartsWith('#'))
            {
                return new ParsedCommand(original, string.Empty, [], string.Empty, false, '\n', false, true);
            }

            var extended = false;
            var separator = '\n';

            if (text.Length > 0 &&
                char.IsPunctuation(text[0]) &&
                text[0] is not '\\' and not '?' and not '_' and not '#')
            {
                extended = true;
                separator = text[0] == '+' ? '\n' : text[0];
                text = text[1..].TrimStart();
            }

            var firstSpace = text.IndexOfAny([' ', '\t']);
            string commandToken;
            string argumentText;

            if (firstSpace < 0)
            {
                commandToken = text;
                argumentText = string.Empty;
            }
            else
            {
                commandToken = text[..firstSpace];
                argumentText = text[(firstSpace + 1)..].Trim();
            }

            var args = argumentText.Length == 0
                ? []
                : argumentText.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            var canonical = Canonicalize(commandToken);
            var quit = canonical == "quit";

            return new ParsedCommand(
                original,
                canonical,
                args,
                argumentText,
                extended,
                separator,
                quit,
                false);
        }

        private static string Canonicalize(string token)
        {
            if (token.StartsWith('\\') || token.StartsWith('/'))
            {
                token = token[1..];
            }

            return token switch
            {
                "P" => "set_pos",
                "p" => "get_pos",
                "M" => "move",
                "S" => "stop",
                "K" => "park",
                "C" => "set_conf",
                "R" => "reset",
                "_" => "get_info",
                "1" => "dump_caps",
                "w" => "send_cmd",
                "q" or "Q" or "exit" => "quit",
                "?" or "help" => "help",
                _ => token.ToLowerInvariant()
            };
        }
    }
}

public sealed record HamlibCommandResult(string Response, bool CloseConnection);
