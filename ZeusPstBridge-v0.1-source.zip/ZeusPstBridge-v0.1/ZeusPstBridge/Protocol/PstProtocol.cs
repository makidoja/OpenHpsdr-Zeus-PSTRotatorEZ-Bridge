using System.Globalization;
using System.Text.RegularExpressions;

namespace ZeusPstBridge.Protocol;

public static partial class PstProtocol
{
    public static string SetAzimuth(double azimuth) =>
        $"<PST><AZIMUTH>{azimuth.ToString("0.###", CultureInfo.InvariantCulture)}</AZIMUTH></PST>";

    public const string QueryAzimuth = "<PST>AZ?</PST>";
    public const string QueryTargetAzimuth = "<PST>TGA?</PST>";
    public const string Stop = "<PST><STOP>1</STOP></PST>";
    public const string Park = "<PST><PARK>1</PARK></PST>";
    public const string On = "<PST><ON>1</ON></PST>";
    public const string Track = "<PST><TRACK>1</TRACK></PST>";

    public static bool TryParseReply(string line, out PstReply reply)
    {
        reply = default;
        var match = ReplyRegex().Match(line.Trim('\0', '\r', '\n', ' ', '\t'));
        if (!match.Success)
        {
            return false;
        }

        if (!double.TryParse(
                match.Groups[2].Value,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out var value))
        {
            return false;
        }

        reply = new PstReply(match.Groups[1].Value.ToUpperInvariant(), value);
        return true;
    }

    [GeneratedRegex(@"^(AZ|TGA)\s*:\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+))", RegexOptions.IgnoreCase)]
    private static partial Regex ReplyRegex();
}

public readonly record struct PstReply(string Type, double Value);
