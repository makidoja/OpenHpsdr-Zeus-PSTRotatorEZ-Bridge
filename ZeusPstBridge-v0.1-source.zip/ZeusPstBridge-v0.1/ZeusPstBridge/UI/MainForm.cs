using System.Diagnostics;
using System.Globalization;
using ZeusPstBridge.Models;
using ZeusPstBridge.Services;

namespace ZeusPstBridge.UI;

public sealed class MainForm : Form
{
    private const string ColId = "Id";
    private const string ColEnabled = "Enabled";
    private const string ColName = "ChannelName";
    private const string ColListenAddress = "ListenAddress";
    private const string ColTcpPort = "TcpPort";
    private const string ColPstHost = "PstHost";
    private const string ColPstCommandPort = "PstCommandPort";
    private const string ColPstReplyPort = "PstReplyPort";
    private const string ColPollMs = "PollMs";
    private const string ColMinAz = "MinAz";
    private const string ColMaxAz = "MaxAz";
    private const string ColZeusStatus = "ZeusStatus";
    private const string ColPstStatus = "PstStatus";
    private const string ColCurrentAz = "CurrentAz";
    private const string ColTargetAz = "TargetAz";
    private const string ColLastReply = "LastReply";

    private readonly ConfigStore _configStore;
    private readonly LogService _logger;
    private readonly BridgeManager _bridgeManager;
    private readonly DataGridView _grid = new();
    private readonly RichTextBox _logBox = new();
    private readonly Button _startButton = new();
    private readonly Button _stopButton = new();
    private readonly Button _saveApplyButton = new();
    private readonly Button _stopAllButton = new();
    private readonly Button _queryButton = new();
    private readonly Button _goButton = new();
    private readonly Button _stopSelectedButton = new();
    private readonly Button _parkButton = new();
    private readonly Button _openConfigButton = new();
    private readonly NumericUpDown _azimuthInput = new();
    private readonly CheckBox _autoStartCheckBox = new();
    private readonly CheckBox _trafficLogCheckBox = new();
    private readonly ToolStripStatusLabel _statusLabel = new();
    private readonly System.Windows.Forms.Timer _uiTimer = new();

    private AppConfig _config;
    private bool _closing;

    public MainForm(ConfigStore configStore, LogService logger)
    {
        _configStore = configStore;
        _logger = logger;
        _bridgeManager = new BridgeManager(_logger);
        _config = _configStore.Load();

        Text = "Zeus ↔ PstRotatorAz Bridge v0.1";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1180, 680);
        Size = new Size(1500, 840);
        Font = new Font("Segoe UI", 9F);

        BuildInterface();
        PopulateGrid(_config);
        SetRunningState(false);

        _logger.EntryAdded += LoggerOnEntryAdded;
        _uiTimer.Interval = 250;
        _uiTimer.Tick += (_, _) => RefreshStatuses();
        _uiTimer.Start();

        Shown += async (_, _) =>
        {
            AppendLog(new LogEntry(DateTimeOffset.Now, LogLevel.Information, $"Configuration: {_configStore.ConfigPath}"));
            if (_config.AutoStart)
            {
                await StartBridgeAsync();
            }
        };

        FormClosing += OnFormClosing;
    }

    private void BuildInterface()
    {
        var toolbar = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(8),
            WrapContents = true
        };

        ConfigureButton(_startButton, "Start Bridge", async (_, _) => await StartBridgeAsync());
        ConfigureButton(_stopButton, "Stop Bridge", async (_, _) => await StopBridgeAsync());
        ConfigureButton(_saveApplyButton, "Save && Apply", async (_, _) => await SaveAndApplyAsync());
        ConfigureButton(_stopAllButton, "STOP ALL", async (_, _) => await StopAllAsync());
        _stopAllButton.Font = new Font(Font, FontStyle.Bold);
        _stopAllButton.AutoSize = false;
        _stopAllButton.Size = new Size(100, 32);

        ConfigureButton(_queryButton, "Query Selected", async (_, _) => await RunForSelectedAsync(id => _bridgeManager.QueryAsync(id)));
        ConfigureButton(_goButton, "Go", async (_, _) => await RunForSelectedAsync(id => _bridgeManager.SetAzimuthAsync(id, (double)_azimuthInput.Value)));
        ConfigureButton(_stopSelectedButton, "Stop Selected", async (_, _) => await RunForSelectedAsync(id => _bridgeManager.StopRotatorAsync(id)));
        ConfigureButton(_parkButton, "Park Selected", async (_, _) => await RunForSelectedAsync(id => _bridgeManager.ParkAsync(id)));
        ConfigureButton(_openConfigButton, "Open Config Folder", (_, _) => OpenConfigFolder());

        _azimuthInput.DecimalPlaces = 1;
        _azimuthInput.Minimum = -180;
        _azimuthInput.Maximum = 540;
        _azimuthInput.Value = 180;
        _azimuthInput.Width = 80;
        _azimuthInput.Margin = new Padding(12, 5, 3, 3);

        _autoStartCheckBox.Text = "Start bridge when program opens";
        _autoStartCheckBox.Checked = _config.AutoStart;
        _autoStartCheckBox.AutoSize = true;
        _autoStartCheckBox.Margin = new Padding(16, 8, 3, 3);

        _trafficLogCheckBox.Text = "Protocol traffic log";
        _trafficLogCheckBox.Checked = _config.LogProtocolTraffic;
        _trafficLogCheckBox.AutoSize = true;
        _trafficLogCheckBox.Margin = new Padding(10, 8, 3, 3);

        toolbar.Controls.AddRange([
            _startButton,
            _stopButton,
            _saveApplyButton,
            _stopAllButton,
            _queryButton,
            new Label { Text = "Set AZ:", AutoSize = true, Margin = new Padding(12, 9, 0, 0) },
            _azimuthInput,
            _goButton,
            _stopSelectedButton,
            _parkButton,
            _autoStartCheckBox,
            _trafficLogCheckBox,
            _openConfigButton
        ]);

        ConfigureGrid();

        _logBox.Dock = DockStyle.Fill;
        _logBox.ReadOnly = true;
        _logBox.WordWrap = false;
        _logBox.BackColor = SystemColors.Window;
        _logBox.Font = new Font("Consolas", 9F);
        _logBox.DetectUrls = false;

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            SplitterDistance = 460,
            Panel1MinSize = 280,
            Panel2MinSize = 120
        };
        split.Panel1.Controls.Add(_grid);
        split.Panel2.Controls.Add(_logBox);

        var statusStrip = new StatusStrip();
        statusStrip.Items.Add(_statusLabel);

        Controls.Add(split);
        Controls.Add(toolbar);
        Controls.Add(statusStrip);
    }

    private void ConfigureGrid()
    {
        _grid.Dock = DockStyle.Fill;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AllowUserToOrderColumns = true;
        _grid.AutoGenerateColumns = false;
        _grid.RowHeadersVisible = false;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = false;
        _grid.EditMode = DataGridViewEditMode.EditOnEnter;
        _grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
        _grid.RowTemplate.Height = 28;

        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = ColId, Visible = false });
        _grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = ColEnabled, HeaderText = "On", Width = 42 });
        _grid.Columns.Add(TextColumn(ColName, "Name", 110));
        _grid.Columns.Add(TextColumn(ColListenAddress, "Zeus listen IP", 105));
        _grid.Columns.Add(TextColumn(ColTcpPort, "TCP", 58));
        _grid.Columns.Add(TextColumn(ColPstHost, "PST IP / host", 125));
        _grid.Columns.Add(TextColumn(ColPstCommandPort, "PST port", 70));
        _grid.Columns.Add(TextColumn(ColPstReplyPort, "Reply", 65));
        _grid.Columns.Add(TextColumn(ColPollMs, "Poll ms", 67));
        _grid.Columns.Add(TextColumn(ColMinAz, "Min AZ", 62));
        _grid.Columns.Add(TextColumn(ColMaxAz, "Max AZ", 62));
        _grid.Columns.Add(StatusColumn(ColZeusStatus, "Zeus", 85));
        _grid.Columns.Add(StatusColumn(ColPstStatus, "PST", 75));
        _grid.Columns.Add(StatusColumn(ColCurrentAz, "Current", 68));
        _grid.Columns.Add(StatusColumn(ColTargetAz, "Target", 68));
        _grid.Columns.Add(StatusColumn(ColLastReply, "Last reply", 92));

        _grid.CellValidating += GridOnCellValidating;
        _grid.DataError += (_, eventArgs) =>
        {
            eventArgs.ThrowException = false;
            MessageBox.Show(eventArgs.Exception?.Message ?? "Invalid grid value.", "Invalid value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        };
    }

    private static DataGridViewTextBoxColumn TextColumn(string name, string header, int width) => new()
    {
        Name = name,
        HeaderText = header,
        Width = width,
        SortMode = DataGridViewColumnSortMode.NotSortable
    };

    private static DataGridViewTextBoxColumn StatusColumn(string name, string header, int width) => new()
    {
        Name = name,
        HeaderText = header,
        Width = width,
        ReadOnly = true,
        SortMode = DataGridViewColumnSortMode.NotSortable,
        DefaultCellStyle = new DataGridViewCellStyle { BackColor = SystemColors.ControlLight }
    };

    private static void ConfigureButton(Button button, string text, EventHandler click)
    {
        button.Text = text;
        button.AutoSize = true;
        button.Height = 32;
        button.Margin = new Padding(3);
        button.Click += click;
    }

    private void PopulateGrid(AppConfig config)
    {
        _grid.Rows.Clear();

        foreach (var rotator in config.Rotators)
        {
            _grid.Rows.Add(
                rotator.Id,
                rotator.Enabled,
                rotator.Name,
                rotator.ListenAddress,
                rotator.TcpPort,
                rotator.PstHost,
                rotator.PstCommandPort,
                rotator.PstReplyPort,
                rotator.PollIntervalMs,
                rotator.MinAzimuth,
                rotator.MaxAzimuth,
                "Stopped",
                "Offline",
                "—",
                "—",
                "—");
        }
    }

    private AppConfig ReadConfigFromGrid()
    {
        _grid.EndEdit();
        var config = new AppConfig
        {
            Version = 1,
            AutoStart = _autoStartCheckBox.Checked,
            LogProtocolTraffic = _trafficLogCheckBox.Checked
        };

        foreach (DataGridViewRow row in _grid.Rows)
        {
            var id = ParseGuid(row.Cells[ColId].Value);
            var previous = _config.Rotators.FirstOrDefault(item => item.Id == id);
            var rotator = new RotatorConfig
            {
                Id = id,
                Enabled = Convert.ToBoolean(row.Cells[ColEnabled].Value ?? false),
                Name = CellString(row, ColName),
                ListenAddress = CellString(row, ColListenAddress),
                TcpPort = CellInt(row, ColTcpPort),
                PstHost = CellString(row, ColPstHost),
                PstCommandPort = CellInt(row, ColPstCommandPort),
                PstReplyPort = CellInt(row, ColPstReplyPort),
                PollIntervalMs = CellInt(row, ColPollMs),
                OfflineTimeoutMs = previous?.OfflineTimeoutMs ?? Math.Max(3000, CellInt(row, ColPollMs) * 4),
                MinAzimuth = CellDouble(row, ColMinAz),
                MaxAzimuth = CellDouble(row, ColMaxAz),
                QueryTarget = previous?.QueryTarget ?? true,
                SendOnAtStart = previous?.SendOnAtStart ?? false,
                SendTrackAtStart = previous?.SendTrackAtStart ?? false
            };
            rotator.Normalize();
            config.Rotators.Add(rotator);
        }

        config.Normalize();
        return config;
    }

    private async Task StartBridgeAsync()
    {
        if (_bridgeManager.IsRunning)
        {
            return;
        }

        try
        {
            _config = ReadConfigFromGrid();
            _configStore.Save(_config);
            SetBusy(true, "Starting bridge…");
            await _bridgeManager.StartAsync(_config);
            SetRunningState(true);
        }
        catch (Exception ex)
        {
            _logger.Error($"Bridge start failed: {ex.Message}");
            MessageBox.Show(ex.Message, "Could not start bridge", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SetRunningState(false);
        }
        finally
        {
            SetBusy(false, null);
        }
    }

    private async Task StopBridgeAsync()
    {
        try
        {
            SetBusy(true, "Stopping bridge…");
            await _bridgeManager.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.Error($"Bridge stop failed: {ex.Message}");
            MessageBox.Show(ex.Message, "Could not stop bridge", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetRunningState(false);
            SetBusy(false, null);
        }
    }

    private async Task SaveAndApplyAsync()
    {
        var wasRunning = _bridgeManager.IsRunning;
        try
        {
            _config = ReadConfigFromGrid();
            _configStore.Save(_config);
            _logger.Info("Configuration saved");

            if (wasRunning)
            {
                await _bridgeManager.StopAsync();
                await _bridgeManager.StartAsync(_config);
                SetRunningState(true);
            }
        }
        catch (Exception ex)
        {
            _logger.Error($"Save/apply failed: {ex.Message}");
            MessageBox.Show(ex.Message, "Could not apply settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SetRunningState(_bridgeManager.IsRunning);
        }
    }

    private async Task StopAllAsync()
    {
        if (!_bridgeManager.IsRunning)
        {
            return;
        }

        try
        {
            await _bridgeManager.StopAllRotatorsAsync();
        }
        catch (Exception ex)
        {
            _logger.Error($"STOP ALL failed: {ex.Message}");
            MessageBox.Show(ex.Message, "STOP ALL failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async Task RunForSelectedAsync(Func<Guid, Task> operation)
    {
        if (!_bridgeManager.IsRunning)
        {
            MessageBox.Show("Start the bridge first.", "Bridge stopped", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var id = GetSelectedId();
        if (id == Guid.Empty)
        {
            return;
        }

        try
        {
            await operation(id);
        }
        catch (Exception ex)
        {
            _logger.Error($"Selected-channel command failed: {ex.Message}");
            MessageBox.Show(ex.Message, "Command failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void RefreshStatuses()
    {
        var statuses = _bridgeManager.GetStatuses();

        foreach (DataGridViewRow row in _grid.Rows)
        {
            var id = ParseGuid(row.Cells[ColId].Value);
            if (!statuses.TryGetValue(id, out var status))
            {
                row.Cells[ColZeusStatus].Value = "Stopped";
                row.Cells[ColPstStatus].Value = "Offline";
                row.Cells[ColCurrentAz].Value = "—";
                row.Cells[ColTargetAz].Value = "—";
                row.Cells[ColLastReply].Value = "—";
                continue;
            }

            row.Cells[ColZeusStatus].Value = status.ConnectedClients > 0
                ? $"{status.ConnectedClients} client" + (status.ConnectedClients == 1 ? string.Empty : "s")
                : "Listening";
            row.Cells[ColPstStatus].Value = status.PstOnline ? "Online" : "Offline";
            row.Cells[ColCurrentAz].Value = status.CurrentAzimuth?.ToString("0.0°", CultureInfo.InvariantCulture) ?? "—";
            row.Cells[ColTargetAz].Value = status.TargetAzimuth?.ToString("0.0°", CultureInfo.InvariantCulture) ?? "—";
            row.Cells[ColLastReply].Value = status.LastReplyUtc.HasValue
                ? status.LastReplyUtc.Value.ToLocalTime().ToString("HH:mm:ss")
                : "—";
        }

        _statusLabel.Text = _bridgeManager.IsRunning
            ? $"Running — {_bridgeManager.GetStatuses().Count} channel(s)"
            : "Stopped";
    }

    private void SetRunningState(bool running)
    {
        _startButton.Enabled = !running;
        _stopButton.Enabled = running;
        _stopAllButton.Enabled = running;
        _queryButton.Enabled = running;
        _goButton.Enabled = running;
        _stopSelectedButton.Enabled = running;
        _parkButton.Enabled = running;
        _grid.ReadOnly = running;

        foreach (DataGridViewColumn column in _grid.Columns)
        {
            if (column.Name is ColZeusStatus or ColPstStatus or ColCurrentAz or ColTargetAz or ColLastReply)
            {
                column.ReadOnly = true;
            }
        }

        _statusLabel.Text = running ? "Running" : "Stopped";
    }

    private void SetBusy(bool busy, string? message)
    {
        UseWaitCursor = busy;
        if (!string.IsNullOrWhiteSpace(message))
        {
            _statusLabel.Text = message;
        }
    }

    private void LoggerOnEntryAdded(LogEntry entry)
    {
        if (_closing || IsDisposed)
        {
            return;
        }

        try
        {
            BeginInvoke(new Action(() => AppendLog(entry)));
        }
        catch (InvalidOperationException)
        {
            // Form is closing.
        }
    }

    private void AppendLog(LogEntry entry)
    {
        if (_logBox.Lines.Length > 3000)
        {
            var lines = _logBox.Lines;
            _logBox.Lines = lines.Skip(lines.Length - 2000).ToArray();
        }

        _logBox.AppendText(entry + Environment.NewLine);
        _logBox.SelectionStart = _logBox.TextLength;
        _logBox.ScrollToCaret();
    }

    private void OpenConfigFolder()
    {
        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = _configStore.BaseDirectory,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Could not open folder", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private async void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (_closing)
        {
            return;
        }

        e.Cancel = true;
        _closing = true;
        Enabled = false;
        _uiTimer.Stop();
        _logger.EntryAdded -= LoggerOnEntryAdded;

        try
        {
            _config = ReadConfigFromGrid();
            _configStore.Save(_config);
            await _bridgeManager.DisposeAsync();
        }
        catch
        {
            // Best-effort shutdown.
        }
        finally
        {
            FormClosing -= OnFormClosing;
            Close();
        }
    }

    private void GridOnCellValidating(object? sender, DataGridViewCellValidatingEventArgs e)
    {
        var columnName = _grid.Columns[e.ColumnIndex].Name;
        if (columnName is ColTcpPort or ColPstCommandPort or ColPstReplyPort or ColPollMs)
        {
            if (!int.TryParse(Convert.ToString(e.FormattedValue), out _))
            {
                e.Cancel = true;
                MessageBox.Show("Enter a whole number.", "Invalid value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        else if (columnName is ColMinAz or ColMaxAz)
        {
            if (!double.TryParse(
                    Convert.ToString(e.FormattedValue),
                    NumberStyles.Float,
                    CultureInfo.CurrentCulture,
                    out _))
            {
                e.Cancel = true;
                MessageBox.Show("Enter a valid number.", "Invalid value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

    private Guid GetSelectedId()
    {
        if (_grid.SelectedRows.Count == 0)
        {
            MessageBox.Show("Select a rotator row first.", "No rotator selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return Guid.Empty;
        }

        return ParseGuid(_grid.SelectedRows[0].Cells[ColId].Value);
    }

    private static Guid ParseGuid(object? value) =>
        Guid.TryParse(Convert.ToString(value), out var id) && id != Guid.Empty ? id : Guid.NewGuid();

    private static string CellString(DataGridViewRow row, string column) =>
        Convert.ToString(row.Cells[column].Value)?.Trim() ?? string.Empty;

    private static int CellInt(DataGridViewRow row, string column) =>
        int.Parse(CellString(row, column), NumberStyles.Integer, CultureInfo.CurrentCulture);

    private static double CellDouble(DataGridViewRow row, string column) =>
        double.Parse(CellString(row, column), NumberStyles.Float, CultureInfo.CurrentCulture);
}
