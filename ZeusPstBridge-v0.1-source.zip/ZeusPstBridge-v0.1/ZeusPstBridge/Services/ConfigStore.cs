using System.Text.Json;
using ZeusPstBridge.Models;

namespace ZeusPstBridge.Services;

public sealed class ConfigStore
{
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public ConfigStore()
    {
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        BaseDirectory = Path.Combine(localAppData, "ZeusPstBridge");
        LogDirectory = Path.Combine(BaseDirectory, "Logs");
        ConfigPath = Path.Combine(BaseDirectory, "config.json");

        Directory.CreateDirectory(BaseDirectory);
        Directory.CreateDirectory(LogDirectory);
    }

    public string BaseDirectory { get; }
    public string LogDirectory { get; }
    public string ConfigPath { get; }

    public AppConfig Load()
    {
        try
        {
            if (!File.Exists(ConfigPath))
            {
                var defaults = AppConfig.CreateDefault();
                Save(defaults);
                return defaults;
            }

            var json = File.ReadAllText(ConfigPath);
            var config = JsonSerializer.Deserialize<AppConfig>(json, _jsonOptions) ?? AppConfig.CreateDefault();
            config.Normalize();
            return config;
        }
        catch
        {
            var backupPath = ConfigPath + ".bad-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
            if (File.Exists(ConfigPath))
            {
                File.Copy(ConfigPath, backupPath, overwrite: true);
            }

            var defaults = AppConfig.CreateDefault();
            Save(defaults);
            return defaults;
        }
    }

    public void Save(AppConfig config)
    {
        config.Normalize();
        Directory.CreateDirectory(BaseDirectory);

        var json = JsonSerializer.Serialize(config, _jsonOptions);
        var temporaryPath = ConfigPath + ".tmp";
        File.WriteAllText(temporaryPath, json);
        File.Move(temporaryPath, ConfigPath, overwrite: true);
    }
}
