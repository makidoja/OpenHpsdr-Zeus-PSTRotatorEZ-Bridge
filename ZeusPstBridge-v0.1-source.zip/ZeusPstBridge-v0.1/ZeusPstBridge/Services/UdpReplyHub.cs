using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ZeusPstBridge.Services;

public sealed class UdpReplyHub : IAsyncDisposable
{
    private readonly LogService _logger;
    private readonly Dictionary<int, UdpClient> _listeners = [];
    private readonly List<Task> _receiveTasks = [];
    private CancellationTokenSource? _cts;

    public UdpReplyHub(LogService logger)
    {
        _logger = logger;
    }

    public event Action<int, IPEndPoint, string>? DatagramReceived;

    public Task StartAsync(IEnumerable<int> ports, CancellationToken cancellationToken = default)
    {
        if (_cts is not null)
        {
            throw new InvalidOperationException("UDP reply hub is already running.");
        }

        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        foreach (var port in ports.Distinct().OrderBy(value => value))
        {
            var client = new UdpClient(AddressFamily.InterNetwork);
            client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, false);
            client.Client.Bind(new IPEndPoint(IPAddress.Any, port));
            _listeners.Add(port, client);
            _receiveTasks.Add(Task.Run(() => ReceiveLoopAsync(port, client, _cts.Token)));
            _logger.Info($"UDP reply listener opened on 0.0.0.0:{port}");
        }

        return Task.CompletedTask;
    }

    public async Task StopAsync()
    {
        var cts = _cts;
        if (cts is null)
        {
            return;
        }

        _cts = null;
        cts.Cancel();

        foreach (var listener in _listeners.Values)
        {
            listener.Dispose();
        }

        try
        {
            await Task.WhenAll(_receiveTasks).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Expected on shutdown.
        }
        catch (ObjectDisposedException)
        {
            // Expected on shutdown.
        }

        _receiveTasks.Clear();
        _listeners.Clear();
        cts.Dispose();
    }

    private async Task ReceiveLoopAsync(int localPort, UdpClient client, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                var result = await client.ReceiveAsync(cancellationToken).ConfigureAwait(false);
                var text = Encoding.ASCII.GetString(result.Buffer);
                DatagramReceived?.Invoke(localPort, result.RemoteEndPoint, text);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (SocketException ex) when (cancellationToken.IsCancellationRequested)
            {
                _logger.Debug($"UDP listener {localPort} stopped: {ex.SocketErrorCode}");
                break;
            }
            catch (Exception ex)
            {
                _logger.Error($"UDP listener {localPort} error: {ex.Message}");
                await Task.Delay(250, cancellationToken).ConfigureAwait(false);
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync().ConfigureAwait(false);
    }
}
