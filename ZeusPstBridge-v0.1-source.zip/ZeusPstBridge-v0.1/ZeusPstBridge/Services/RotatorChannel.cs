using System.Net;
using System.Net.Sockets;
using System.Text;
using ZeusPstBridge.Models;
using ZeusPstBridge.Protocol;

namespace ZeusPstBridge.Services;

public sealed class RotatorChannel : IAsyncDisposable
{
    private readonly object _stateLock = new();
    private readonly RotatorConfig _config;
    private readonly int _startupOffsetMs;
    private readonly LogService _logger;
    private readonly bool _logProtocolTraffic;
    private readonly UdpClient _udpSender = new(AddressFamily.InterNetwork);
    private readonly HashSet<IPAddress> _resolvedPstAddresses = [];
    private readonly List<Task> _clientTasks = [];

    private CancellationTokenSource? _cts;
    private TcpListener? _tcpListener;
    private Task? _acceptTask;
    private Task? _pollTask;
    private IPEndPoint? _pstEndpoint;
    private int _connectedClients;
    private double? _currentAzimuth;
    private double? _targetAzimuth;
    private DateTimeOffset? _lastReplyUtc;
    private string _lastError = string.Empty;
    private bool _running;

    public RotatorChannel(
        RotatorConfig config,
        int startupOffsetMs,
        LogService logger,
        bool logProtocolTraffic)
    {
        _config = config.Clone();
        _startupOffsetMs = startupOffsetMs;
        _logger = logger;
        _logProtocolTraffic = logProtocolTraffic;
    }

    public RotatorConfig Config => _config;
    public IReadOnlyCollection<IPAddress> ResolvedPstAddresses => _resolvedPstAddresses;

    public async Task StartAsync(CancellationToken cancellationToken = default)
    {
        if (_running)
        {
            throw new InvalidOperationException($"Channel {_config.Name} is already running.");
        }

        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        var listenAddress = ParseListenAddress(_config.ListenAddress);
        var addresses = await Dns.GetHostAddressesAsync(_config.PstHost, _cts.Token).ConfigureAwait(false);
        var pstAddress = addresses.FirstOrDefault(address => address.AddressFamily == AddressFamily.InterNetwork)
                         ?? throw new InvalidOperationException(
                             $"No IPv4 address could be resolved for PstRotatorAz host '{_config.PstHost}'.");

        foreach (var address in addresses.Where(address => address.AddressFamily == AddressFamily.InterNetwork))
        {
            _resolvedPstAddresses.Add(address);
        }

        _pstEndpoint = new IPEndPoint(pstAddress, _config.PstCommandPort);
        _tcpListener = new TcpListener(listenAddress, _config.TcpPort);
        _tcpListener.Start();
        _running = true;

        _acceptTask = Task.Run(() => AcceptLoopAsync(_cts.Token));
        _pollTask = Task.Run(() => PollLoopAsync(_cts.Token));

        _logger.Info(
            $"[{_config.Name}] Listening for Zeus on {_config.ListenAddress}:{_config.TcpPort}; " +
            $"PST destination {_pstEndpoint}; replies on UDP {_config.EffectiveReplyPort}");

        if (_config.SendOnAtStart)
        {
            await SendPstAsync(PstProtocol.On).ConfigureAwait(false);
        }

        if (_config.SendTrackAtStart)
        {
            await SendPstAsync(PstProtocol.Track).ConfigureAwait(false);
        }
    }

    public async Task StopAsync()
    {
        var cts = _cts;
        if (cts is null)
        {
            return;
        }

        _cts = null;
        _running = false;
        cts.Cancel();
        _tcpListener?.Stop();

        var tasks = new List<Task>();
        if (_acceptTask is not null)
        {
            tasks.Add(_acceptTask);
        }
        if (_pollTask is not null)
        {
            tasks.Add(_pollTask);
        }

        lock (_clientTasks)
        {
            tasks.AddRange(_clientTasks);
        }

        try
        {
            await Task.WhenAll(tasks).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Expected on shutdown.
        }
        catch (ObjectDisposedException)
        {
            // Expected on shutdown.
        }
        catch (SocketException)
        {
            // Expected when the listener is stopped.
        }

        _tcpListener = null;
        _acceptTask = null;
        _pollTask = null;
        cts.Dispose();
        _logger.Info($"[{_config.Name}] Stopped");
    }

    public bool MatchesReply(int localReplyPort, IPAddress sourceAddress)
    {
        return _config.EffectiveReplyPort == localReplyPort && _resolvedPstAddresses.Contains(sourceAddress);
    }

    public void HandlePstDatagram(IPEndPoint remoteEndpoint, string datagram)
    {
        if (_logProtocolTraffic)
        {
            _logger.Debug($"[{_config.Name}] PST {remoteEndpoint} -> {Escape(datagram)}");
        }

        var foundReply = false;
        var lines = datagram.Split(['\r', '\n', '\0'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        foreach (var line in lines)
        {
            if (!PstProtocol.TryParseReply(line, out var reply))
            {
                continue;
            }

            foundReply = true;
            lock (_stateLock)
            {
                if (reply.Type == "AZ")
                {
                    _currentAzimuth = reply.Value;
                }
                else if (reply.Type == "TGA")
                {
                    _targetAzimuth = reply.Value;
                }

                _lastReplyUtc = DateTimeOffset.UtcNow;
                _lastError = string.Empty;
            }
        }

        if (!foundReply)
        {
            _logger.Warn($"[{_config.Name}] Unrecognised PST UDP reply: {Escape(datagram)}");
        }
    }

    public ChannelStatus GetStatus()
    {
        lock (_stateLock)
        {
            var online = _lastReplyUtc.HasValue &&
                         DateTimeOffset.UtcNow - _lastReplyUtc.Value <= TimeSpan.FromMilliseconds(_config.OfflineTimeoutMs);

            return new ChannelStatus(
                _config.Id,
                _config.Name,
                _running,
                Volatile.Read(ref _connectedClients),
                online,
                _currentAzimuth,
                _targetAzimuth,
                _lastReplyUtc,
                _lastError);
        }
    }

    public Task QueryPositionAsync() => SendPstAsync(PstProtocol.QueryAzimuth);
    public Task QueryTargetAsync() => SendPstAsync(PstProtocol.QueryTargetAzimuth);
    public Task SetAzimuthAsync(double azimuth) => SendPstAsync(PstProtocol.SetAzimuth(azimuth));
    public Task StopRotatorAsync() => SendPstAsync(PstProtocol.Stop);
    public Task ParkAsync() => SendPstAsync(PstProtocol.Park);

    private async Task AcceptLoopAsync(CancellationToken cancellationToken)
    {
        var listener = _tcpListener ?? throw new InvalidOperationException("TCP listener is not available.");

        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                var client = await listener.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);
                client.NoDelay = true;
                var task = HandleClientAsync(client, cancellationToken);

                lock (_clientTasks)
                {
                    _clientTasks.Add(task);
                }

                _ = task.ContinueWith(
                    completedTask =>
                    {
                        lock (_clientTasks)
                        {
                            _clientTasks.Remove(completedTask);
                        }
                    },
                    CancellationToken.None,
                    TaskContinuationOptions.ExecuteSynchronously,
                    TaskScheduler.Default);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (ObjectDisposedException)
            {
                break;
            }
            catch (SocketException) when (cancellationToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                SetError($"TCP accept error: {ex.Message}");
                _logger.Error($"[{_config.Name}] TCP accept error: {ex.Message}");
                await Task.Delay(250, cancellationToken).ConfigureAwait(false);
            }
        }
    }

    private async Task HandleClientAsync(TcpClient client, CancellationToken cancellationToken)
    {
        var remote = client.Client.RemoteEndPoint?.ToString() ?? "unknown";
        Interlocked.Increment(ref _connectedClients);
        _logger.Info($"[{_config.Name}] Zeus/Hamlib client connected from {remote}");

        try
        {
            await using var stream = client.GetStream();
            using var reader = new StreamReader(stream, Encoding.ASCII, false, 4096, leaveOpen: true);
            await using var writer = new StreamWriter(stream, new UTF8Encoding(false), 4096, leaveOpen: true)
            {
                AutoFlush = true,
                NewLine = "\n"
            };

            var protocol = new HamlibProtocol(
                _config,
                () => GetStatus().CurrentAzimuth,
                () => GetStatus().TargetAzimuth,
                SetAzimuthAsync,
                StopRotatorAsync,
                ParkAsync,
                _logger);

            while (!cancellationToken.IsCancellationRequested && client.Connected)
            {
                string? line;
                try
                {
                    line = await reader.ReadLineAsync().WaitAsync(cancellationToken).ConfigureAwait(false);
                }
                catch (OperationCanceledException)
                {
                    break;
                }

                if (line is null)
                {
                    break;
                }

                if (_logProtocolTraffic)
                {
                    _logger.Debug($"[{_config.Name}] Zeus {remote} -> {line}");
                }

                var result = await protocol.ExecuteAsync(line).ConfigureAwait(false);
                if (result.Response.Length > 0)
                {
                    await writer.WriteAsync(result.Response).ConfigureAwait(false);
                    if (_logProtocolTraffic)
                    {
                        _logger.Debug($"[{_config.Name}] Zeus {remote} <- {Escape(result.Response)}");
                    }
                }

                if (result.CloseConnection)
                {
                    break;
                }
            }
        }
        catch (IOException ex)
        {
            _logger.Debug($"[{_config.Name}] Zeus client {remote} disconnected: {ex.Message}");
        }
        catch (SocketException ex)
        {
            _logger.Debug($"[{_config.Name}] Zeus client {remote} socket closed: {ex.SocketErrorCode}");
        }
        catch (Exception ex)
        {
            _logger.Error($"[{_config.Name}] Zeus client {remote} error: {ex.Message}");
        }
        finally
        {
            client.Dispose();
            Interlocked.Decrement(ref _connectedClients);
            _logger.Info($"[{_config.Name}] Zeus/Hamlib client disconnected from {remote}");
        }
    }

    private async Task PollLoopAsync(CancellationToken cancellationToken)
    {
        if (_startupOffsetMs > 0)
        {
            await Task.Delay(_startupOffsetMs, cancellationToken).ConfigureAwait(false);
        }

        var targetCounter = 0;
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await QueryPositionAsync().ConfigureAwait(false);

                targetCounter += _config.PollIntervalMs;
                if (_config.QueryTarget && targetCounter >= 1000)
                {
                    targetCounter = 0;
                    await QueryTargetAsync().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                SetError($"PST poll error: {ex.Message}");
                _logger.Error($"[{_config.Name}] PST poll error: {ex.Message}");
            }

            await Task.Delay(_config.PollIntervalMs, cancellationToken).ConfigureAwait(false);
        }
    }

    private async Task SendPstAsync(string command)
    {
        var endpoint = _pstEndpoint ?? throw new InvalidOperationException("PST destination has not been resolved.");
        var bytes = Encoding.ASCII.GetBytes(command);
        await _udpSender.SendAsync(bytes, bytes.Length, endpoint).ConfigureAwait(false);

        if (_logProtocolTraffic)
        {
            _logger.Debug($"[{_config.Name}] PST {endpoint} <- {command}");
        }
    }

    private void SetError(string message)
    {
        lock (_stateLock)
        {
            _lastError = message;
        }
    }

    private static IPAddress ParseListenAddress(string address)
    {
        if (address.Equals("localhost", StringComparison.OrdinalIgnoreCase))
        {
            return IPAddress.Loopback;
        }

        if (IPAddress.TryParse(address, out var parsed))
        {
            if (parsed.AddressFamily != AddressFamily.InterNetwork)
            {
                throw new ArgumentException("Only IPv4 listen addresses are supported in this version.");
            }

            return parsed;
        }

        throw new ArgumentException(
            $"Listen address '{address}' is invalid. Use 127.0.0.1 or 0.0.0.0.");
    }

    private static string Escape(string value) =>
        value.Replace("\r", "<CR>").Replace("\n", "<LF>").Replace("\0", "<NUL>");

    public async ValueTask DisposeAsync()
    {
        await StopAsync().ConfigureAwait(false);
        _udpSender.Dispose();
    }
}
