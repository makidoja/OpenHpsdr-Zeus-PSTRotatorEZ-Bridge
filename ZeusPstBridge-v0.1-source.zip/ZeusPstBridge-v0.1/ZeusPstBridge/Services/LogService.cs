namespace ZeusPstBridge.Services;

public enum LogLevel
{
    Debug,
    Information,
    Warning,
    Error
}

public sealed record LogEntry(DateTimeOffset Timestamp, LogLevel Level, string Message)
{
    public override string ToString() => $"{Timestamp:HH:mm:ss.fff} [{Level}] {Message}";
}

public sealed class LogService
{
    private readonly object _sync = new();
    private readonly string _logDirectory;

    public LogService(string logDirectory)
    {
        _logDirectory = logDirectory;
        Directory.CreateDirectory(_logDirectory);
    }

    public event Action<LogEntry>? EntryAdded;

    public void Debug(string message) => Write(LogLevel.Debug, message);
    public void Info(string message) => Write(LogLevel.Information, message);
    public void Warn(string message) => Write(LogLevel.Warning, message);
    public void Error(string message) => Write(LogLevel.Error, message);

    private void Write(LogLevel level, string message)
    {
        var entry = new LogEntry(DateTimeOffset.Now, level, message);

        try
        {
            lock (_sync)
            {
                var path = Path.Combine(_logDirectory, $"ZeusPstBridge-{DateTime.Now:yyyy-MM-dd}.log");
                File.AppendAllText(path, entry + Environment.NewLine);
            }
        }
        catch
        {
            // Logging must never stop the bridge.
        }

        EntryAdded?.Invoke(entry);
    }
}
