using System.Net;
using System.Net.Sockets;
using ZeusPstBridge.Models;

namespace ZeusPstBridge.Services;

public sealed class BridgeManager : IAsyncDisposable
{
    private readonly LogService _logger;
    private readonly Dictionary<Guid, RotatorChannel> _channels = [];
    private UdpReplyHub? _udpHub;
    private bool _running;

    public BridgeManager(LogService logger)
    {
        _logger = logger;
    }

    public bool IsRunning => _running;

    public async Task StartAsync(AppConfig config)
    {
        if (_running)
        {
            throw new InvalidOperationException("The bridge is already running.");
        }

        config.Normalize();
        var enabled = config.Rotators.Where(rotator => rotator.Enabled).Select(rotator => rotator.Clone()).ToList();
        Validate(enabled);

        if (enabled.Count == 0)
        {
            throw new InvalidOperationException("Enable at least one rotator channel.");
        }

        _udpHub = new UdpReplyHub(_logger);
        _udpHub.DatagramReceived += HandleUdpDatagram;

        try
        {
            await _udpHub.StartAsync(enabled.Select(rotator => rotator.EffectiveReplyPort)).ConfigureAwait(false);

            for (var index = 0; index < enabled.Count; index++)
            {
                var channel = new RotatorChannel(
                    enabled[index],
                    startupOffsetMs: index * 50,
                    _logger,
                    config.LogProtocolTraffic);

                _channels.Add(channel.Config.Id, channel);
                await channel.StartAsync().ConfigureAwait(false);
            }

            _running = true;
            _logger.Info($"Bridge started with {enabled.Count} enabled rotator channel(s)");
        }
        catch
        {
            await StopAsync().ConfigureAwait(false);
            throw;
        }
    }

    public async Task StopAsync()
    {
        var channels = _channels.Values.ToList();
        _channels.Clear();

        foreach (var channel in channels)
        {
            try
            {
                await channel.DisposeAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.Error($"Failed to stop channel {channel.Config.Name}: {ex.Message}");
            }
        }

        if (_udpHub is not null)
        {
            _udpHub.DatagramReceived -= HandleUdpDatagram;
            await _udpHub.DisposeAsync().ConfigureAwait(false);
            _udpHub = null;
        }

        if (_running || channels.Count > 0)
        {
            _logger.Info("Bridge stopped");
        }

        _running = false;
    }

    public IReadOnlyDictionary<Guid, ChannelStatus> GetStatuses()
    {
        return _channels.Values.ToDictionary(channel => channel.Config.Id, channel => channel.GetStatus());
    }

    public async Task QueryAsync(Guid id)
    {
        var channel = GetChannel(id);
        await channel.QueryPositionAsync().ConfigureAwait(false);
        if (channel.Config.QueryTarget)
        {
            await channel.QueryTargetAsync().ConfigureAwait(false);
        }
    }

    public Task SetAzimuthAsync(Guid id, double azimuth)
    {
        var channel = GetChannel(id);
        if (azimuth < channel.Config.MinAzimuth || azimuth > channel.Config.MaxAzimuth)
        {
            throw new ArgumentOutOfRangeException(
                nameof(azimuth),
                $"Azimuth must be between {channel.Config.MinAzimuth:0.###} and {channel.Config.MaxAzimuth:0.###}.");
        }

        return channel.SetAzimuthAsync(azimuth);
    }

    public Task StopRotatorAsync(Guid id) => GetChannel(id).StopRotatorAsync();
    public Task ParkAsync(Guid id) => GetChannel(id).ParkAsync();

    public async Task StopAllRotatorsAsync()
    {
        var tasks = _channels.Values.Select(channel => channel.StopRotatorAsync());
        await Task.WhenAll(tasks).ConfigureAwait(false);
        _logger.Warn("STOP ALL sent to every enabled PstRotatorAz channel");
    }

    private void HandleUdpDatagram(int localReplyPort, IPEndPoint remoteEndpoint, string datagram)
    {
        var matches = _channels.Values
            .Where(channel => channel.MatchesReply(localReplyPort, remoteEndpoint.Address))
            .ToList();

        if (matches.Count == 0)
        {
            var candidates = _channels.Values
                .Where(channel => channel.Config.EffectiveReplyPort == localReplyPort)
                .ToList();

            if (candidates.Count == 1)
            {
                _logger.Warn(
                    $"UDP reply on {localReplyPort} came from unexpected address {remoteEndpoint.Address}; " +
                    $"routing it to {candidates[0].Config.Name} because that reply port is unique.");
                candidates[0].HandlePstDatagram(remoteEndpoint, datagram);
                return;
            }

            _logger.Warn(
                $"Ignored UDP reply on {localReplyPort} from {remoteEndpoint}; no unambiguous channel matched.");
            return;
        }

        if (matches.Count > 1)
        {
            _logger.Error(
                $"Ambiguous UDP reply on {localReplyPort} from {remoteEndpoint.Address}; " +
                $"matched {matches.Count} channels. Check PST host/reply-port settings.");
            return;
        }

        matches[0].HandlePstDatagram(remoteEndpoint, datagram);
    }

    private RotatorChannel GetChannel(Guid id)
    {
        if (!_channels.TryGetValue(id, out var channel))
        {
            throw new InvalidOperationException("The selected channel is not currently running.");
        }

        return channel;
    }

    private static void Validate(IReadOnlyList<RotatorConfig> rotators)
    {
        var errors = new List<string>();
        var tcpEndpoints = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var rotator in rotators)
        {
            if (rotator.TcpPort is < 1 or > 65535)
            {
                errors.Add($"{rotator.Name}: Zeus TCP port is invalid.");
            }

            if (rotator.PstCommandPort is < 1 or > 65535)
            {
                errors.Add($"{rotator.Name}: PST command port is invalid.");
            }

            if (rotator.EffectiveReplyPort is < 1 or > 65535)
            {
                errors.Add($"{rotator.Name}: PST reply port is invalid.");
            }

            if (rotator.PollIntervalMs is < 200 or > 10000)
            {
                errors.Add($"{rotator.Name}: Poll interval must be 200 to 10000 ms.");
            }

            if (rotator.MinAzimuth >= rotator.MaxAzimuth)
            {
                errors.Add($"{rotator.Name}: Minimum azimuth must be below maximum azimuth.");
            }

            var tcpKey = $"{rotator.ListenAddress}:{rotator.TcpPort}";
            if (!tcpEndpoints.Add(tcpKey))
            {
                errors.Add($"Duplicate Zeus TCP endpoint: {tcpKey}.");
            }

            if (!IPAddress.TryParse(rotator.ListenAddress, out var listenAddress) ||
                listenAddress.AddressFamily != AddressFamily.InterNetwork)
            {
                errors.Add($"{rotator.Name}: Listen address must be an IPv4 address such as 127.0.0.1 or 0.0.0.0.");
            }

            if (string.IsNullOrWhiteSpace(rotator.PstHost))
            {
                errors.Add($"{rotator.Name}: PST host is required.");
            }
        }

        var ambiguousGroups = rotators
            .GroupBy(
                rotator => $"{rotator.PstHost.Trim().ToLowerInvariant()}:{rotator.EffectiveReplyPort}",
                StringComparer.OrdinalIgnoreCase)
            .Where(group => group.Count() > 1);

        foreach (var group in ambiguousGroups)
        {
            errors.Add(
                $"Ambiguous PST reply route {group.Key}: " +
                string.Join(", ", group.Select(rotator => rotator.Name)) +
                ". Instances on the same host must use different UDP reply ports.");
        }

        if (errors.Count > 0)
        {
            throw new InvalidOperationException(string.Join(Environment.NewLine, errors));
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync().ConfigureAwait(false);
    }
}
