using ZeusPstBridge.Services;
using ZeusPstBridge.UI;

namespace ZeusPstBridge;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        try
        {
            var configStore = new ConfigStore();
            var logger = new LogService(configStore.LogDirectory);
            Application.Run(new MainForm(configStore, logger));
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"ZeusPstBridge could not start.\r\n\r\n{ex}",
                "ZeusPstBridge",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
