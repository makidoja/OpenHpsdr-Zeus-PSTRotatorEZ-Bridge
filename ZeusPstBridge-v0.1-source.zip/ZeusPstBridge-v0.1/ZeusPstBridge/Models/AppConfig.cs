namespace ZeusPstBridge.Models;

public sealed class AppConfig
{
    public int Version { get; set; } = 1;
    public bool AutoStart { get; set; }
    public bool LogProtocolTraffic { get; set; } = true;
    public List<RotatorConfig> Rotators { get; set; } = [];

    public static AppConfig CreateDefault()
    {
        var config = new AppConfig();

        for (var i = 0; i < 10; i++)
        {
            var commandPort = 12000 + (i * 10);
            config.Rotators.Add(new RotatorConfig
            {
                Id = Guid.NewGuid(),
                Enabled = i == 0,
                Name = $"Rotator {i + 1}",
                ListenAddress = "127.0.0.1",
                TcpPort = 4533 + (i * 2),
                PstHost = "127.0.0.1",
                PstCommandPort = commandPort,
                PstReplyPort = commandPort + 1,
                PollIntervalMs = 500,
                OfflineTimeoutMs = 3000,
                MinAzimuth = 0,
                MaxAzimuth = 360,
                QueryTarget = true
            });
        }

        return config;
    }

    public void Normalize()
    {
        Rotators ??= [];

        while (Rotators.Count < 10)
        {
            var i = Rotators.Count;
            var commandPort = 12000 + (i * 10);
            Rotators.Add(new RotatorConfig
            {
                Id = Guid.NewGuid(),
                Enabled = false,
                Name = $"Rotator {i + 1}",
                ListenAddress = "127.0.0.1",
                TcpPort = 4533 + (i * 2),
                PstHost = "127.0.0.1",
                PstCommandPort = commandPort,
                PstReplyPort = commandPort + 1,
                PollIntervalMs = 500,
                OfflineTimeoutMs = 3000,
                MinAzimuth = 0,
                MaxAzimuth = 360,
                QueryTarget = true
            });
        }

        if (Rotators.Count > 10)
        {
            Rotators = Rotators.Take(10).ToList();
        }

        foreach (var rotator in Rotators)
        {
            rotator.Normalize();
        }
    }
}
