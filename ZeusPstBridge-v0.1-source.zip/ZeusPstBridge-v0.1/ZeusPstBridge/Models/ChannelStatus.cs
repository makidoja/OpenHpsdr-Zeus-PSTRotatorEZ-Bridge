namespace ZeusPstBridge.Models;

public sealed record ChannelStatus(
    Guid Id,
    string Name,
    bool Running,
    int ConnectedClients,
    bool PstOnline,
    double? CurrentAzimuth,
    double? TargetAzimuth,
    DateTimeOffset? LastReplyUtc,
    string LastError)
{
    public static ChannelStatus Stopped(RotatorConfig config) => new(
        config.Id,
        config.Name,
        false,
        0,
        false,
        null,
        null,
        null,
        string.Empty);
}
