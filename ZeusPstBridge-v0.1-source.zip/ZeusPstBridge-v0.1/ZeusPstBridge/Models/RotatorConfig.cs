namespace ZeusPstBridge.Models;

public sealed class RotatorConfig
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public bool Enabled { get; set; }
    public string Name { get; set; } = "Rotator";
    public string ListenAddress { get; set; } = "127.0.0.1";
    public int TcpPort { get; set; } = 4533;
    public string PstHost { get; set; } = "127.0.0.1";
    public int PstCommandPort { get; set; } = 12000;
    public int PstReplyPort { get; set; } = 12001;
    public int PollIntervalMs { get; set; } = 500;
    public int OfflineTimeoutMs { get; set; } = 3000;
    public double MinAzimuth { get; set; } = 0;
    public double MaxAzimuth { get; set; } = 360;
    public bool QueryTarget { get; set; } = true;
    public bool SendOnAtStart { get; set; }
    public bool SendTrackAtStart { get; set; }

    public int EffectiveReplyPort => PstReplyPort > 0 ? PstReplyPort : PstCommandPort + 1;

    public void Normalize()
    {
        if (Id == Guid.Empty)
        {
            Id = Guid.NewGuid();
        }

        Name = string.IsNullOrWhiteSpace(Name) ? "Rotator" : Name.Trim();
        ListenAddress = string.IsNullOrWhiteSpace(ListenAddress) ? "127.0.0.1" : ListenAddress.Trim();
        PstHost = string.IsNullOrWhiteSpace(PstHost) ? "127.0.0.1" : PstHost.Trim();
        PollIntervalMs = Math.Clamp(PollIntervalMs, 200, 10000);
        OfflineTimeoutMs = Math.Clamp(OfflineTimeoutMs, Math.Max(1000, PollIntervalMs * 2), 60000);

        if (PstReplyPort <= 0 && PstCommandPort is > 0 and < 65535)
        {
            PstReplyPort = PstCommandPort + 1;
        }
    }

    public RotatorConfig Clone() => new()
    {
        Id = Id,
        Enabled = Enabled,
        Name = Name,
        ListenAddress = ListenAddress,
        TcpPort = TcpPort,
        PstHost = PstHost,
        PstCommandPort = PstCommandPort,
        PstReplyPort = PstReplyPort,
        PollIntervalMs = PollIntervalMs,
        OfflineTimeoutMs = OfflineTimeoutMs,
        MinAzimuth = MinAzimuth,
        MaxAzimuth = MaxAzimuth,
        QueryTarget = QueryTarget,
        SendOnAtStart = SendOnAtStart,
        SendTrackAtStart = SendTrackAtStart
    };
}
