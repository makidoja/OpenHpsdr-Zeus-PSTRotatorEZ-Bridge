param(
    [string]$HostName = "127.0.0.1",
    [int]$Port = 4533,
    [string[]]$Commands = @("+\dump_state", "p", "P 123 0", "p", "S")
)

$ErrorActionPreference = "Stop"
$client = [System.Net.Sockets.TcpClient]::new()
$client.Connect($HostName, $Port)
$stream = $client.GetStream()
$stream.ReadTimeout = 1000
$ascii = [System.Text.Encoding]::ASCII

try {
    foreach ($command in $Commands) {
        Write-Host "> $command" -ForegroundColor Cyan
        $bytes = $ascii.GetBytes($command + "`n")
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush()
        Start-Sleep -Milliseconds 150

        $buffer = New-Object byte[] 8192
        $response = ""
        while ($stream.DataAvailable) {
            $read = $stream.Read($buffer, 0, $buffer.Length)
            if ($read -le 0) { break }
            $response += $ascii.GetString($buffer, 0, $read)
            Start-Sleep -Milliseconds 30
        }

        Write-Host ($response.TrimEnd())
        Write-Host ""
    }
}
finally {
    $client.Dispose()
}
