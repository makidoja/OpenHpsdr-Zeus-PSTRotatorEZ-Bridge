param(
    [string]$ListenAddress = "0.0.0.0",
    [int]$CommandPort = 12000,
    [double]$InitialAzimuth = 180
)

$ErrorActionPreference = "Stop"
$currentAz = $InitialAzimuth
$targetAz = $InitialAzimuth
$listenIp = [System.Net.IPAddress]::Parse($ListenAddress)
$listener = [System.Net.Sockets.UdpClient]::new([System.Net.IPEndPoint]::new($listenIp, $CommandPort))
$sender = [System.Net.Sockets.UdpClient]::new()
$ascii = [System.Text.Encoding]::ASCII

Write-Host "PstRotatorAz UDP simulator listening on $ListenAddress`:$CommandPort"
Write-Host "Replies will be sent to the requester's IP on UDP $($CommandPort + 1)."
Write-Host "Press Ctrl+C to stop."

try {
    while ($true) {
        $remote = [System.Net.IPEndPoint]::new([System.Net.IPAddress]::Any, 0)
        $bytes = $listener.Receive([ref]$remote)
        $text = $ascii.GetString($bytes)
        Write-Host "RX $($remote.Address):$($remote.Port)  $text"

        if ($text -match '<AZIMUTH>\s*([+-]?[0-9]+(?:\.[0-9]+)?)\s*</AZIMUTH>') {
            $targetAz = [double]::Parse($Matches[1], [System.Globalization.CultureInfo]::InvariantCulture)
            $currentAz = $targetAz
            Write-Host "Target/current AZ set to $currentAz"
        }

        $reply = $null
        if ($text -match '<PST>AZ\?</PST>') {
            $reply = "AZ:$currentAz`r"
        }
        elseif ($text -match '<PST>TGA\?</PST>') {
            $reply = "TGA:$targetAz`r"
        }
        elseif ($text -match '<STOP>1</STOP>') {
            Write-Host "STOP received"
        }
        elseif ($text -match '<PARK>1</PARK>') {
            $targetAz = 0
            $currentAz = 0
            Write-Host "PARK received; simulated AZ is now 0"
        }

        if ($null -ne $reply) {
            $replyBytes = $ascii.GetBytes($reply)
            $destination = [System.Net.IPEndPoint]::new($remote.Address, $CommandPort + 1)
            [void]$sender.Send($replyBytes, $replyBytes.Length, $destination)
            Write-Host "TX $($destination.Address):$($destination.Port)  $reply"
        }
    }
}
finally {
    $listener.Dispose()
    $sender.Dispose()
}
